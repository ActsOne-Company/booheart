/**
 * Appcropolis Template: hello 
 * @copy Appcropolis LLC (c) 2011-2013. All rights reserved.
 * @author tskim (support@appcropolis.com)
 * @date 2013-06-07
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN 
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN 
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE 
 * SOFTWARE.
 *
 * License and legal information: 
 *
 * http://appcropolis.com/license/
 * http://appcropolis.com/legal/
 * http://appcropolis.com/privacy/
 */


/* global */



/* header */



/* subheader */
/* (subheader) seed-subheader */



/* content */



/* footer */

